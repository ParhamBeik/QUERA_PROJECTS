class Shooter:
    def set_gun_by_name(self, name: str) -> None:
        pass

    def add_bullet_of_given_size_to_gun(self, size: float, count: int) -> None:
        pass

    def shoot_to_target(self, target_x: int,  target_y: int,  target_distance: int,  aim_x: int,  aim_y: int) -> float:
        pass
