def separator(ls):
    pass
