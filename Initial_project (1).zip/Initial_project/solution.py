def calculator(n, m, li):
    pass
